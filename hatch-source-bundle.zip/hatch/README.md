# Hatch

This snapshot contains the static product bundle (HTML, CSS, and JavaScript) found in the Codex workspace. Editable application source was not present in the available Hatch project folder.
